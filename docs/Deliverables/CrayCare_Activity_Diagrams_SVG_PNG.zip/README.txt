CrayCare Activity Diagrams
Generated programmatically as SVG and rendered to PNG with CairoSVG at 300 DPI.

Rules:
- USER lane is strictly LEFT; user actions are BLUE.
- SYSTEM lane is strictly RIGHT; system processes are GREEN.
- Decisions are YELLOW DIAMONDS.
- START/END nodes are BLACK.
- Orthogonal connectors are used; boxes never change lanes.
